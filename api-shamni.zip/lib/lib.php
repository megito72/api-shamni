<?php
if (!defined('__CONFIG__')) {
	header("location:" . SITE_URL);
	die();
}


function loadVariable($name, $default)
{
	if (isset($_REQUEST[$name]))
		return $_REQUEST[$name];
	else
		return $default;
}

function welcome_msg()
{

	if (date("H") < 18) {

		return "Morning";
	} elseif (date("H") > 17) {

		return "Night";
	}
}

function ShowMessage()
{
	if (isset($_SESSION[MESSAGE_TEXT]) && $_SESSION[MESSAGE_TEXT] <> "") {
		//var_dump($_SESSION[MESSAGE_TEXT]); exit();

		echo '
<div class="alert alert-info alert-with-icon mx-auto" data-notify="container">

 <span data-notify="message">' . $_SESSION[MESSAGE_TEXT] . '</span>
</div>
';

		/*	echo '<div class="alert">
  <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
  <i>'.$_SESSION[MESSAGE_TEXT].'</i>
</div>'; */


		$_SESSION[MESSAGE_TEXT] = "";
		//$_SESSION[MESSAGE_TYPE] = "";
		return true;
	} elseif (isset($_SESSION[MESSAGE_TEXT_ERROR]) && $_SESSION[MESSAGE_TEXT_ERROR] <> "") {
		//var_dump($_SESSION[MESSAGE_TEXT]); exit();


		echo '
<div class="alert alert-danger alert-with-icon mx-auto" data-notify="container">

<span data-notify="message">' . $_SESSION[MESSAGE_TEXT_ERROR] . '</span>
</div>
';
		/*echo '<div class="col-lg-6 mb-4">
                  <div class="card bg-success text-white shadow">
                    <div class="card-body">
                      '.$_SESSION[MESSAGE_TEXT_ERROR].'
                      <div class="text-white-50 small">#1cc88a</div>
                    </div>
                  </div>
                </div>'; */
		/*	echo '<div class="alert">
  <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
  <i>'.$_SESSION[MESSAGE_TEXT].'</i>
</div>'; */


		$_SESSION[MESSAGE_TEXT_ERROR] = "";
		//$_SESSION[MESSAGE_TYPE] = "";
		return true;
	}


	if (isset($_SESSION[MESSAGE_TEXT_IPL]) && $_SESSION[MESSAGE_TEXT_IPL] <> "") {
		//var_dump($_SESSION[MESSAGE_TEXT]); exit();

		echo '
<div class="alert mx-auto" style=" display: block;
    position: fixed;
    z-index: 9999;
    background-color: green;
    left: 25%;
    top: 50%;
    right: 25%;
    color: black;"
	data-notify="container">

 <span data-notify="message" style="color:green;">' . $_SESSION[MESSAGE_TEXT_IPL] . '</span>
</div>
';

		/*	echo '<div class="alert">
  <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
  <i>'.$_SESSION[MESSAGE_TEXT].'</i>
</div>'; */


		$_SESSION[MESSAGE_TEXT_IPL] = "";
		//$_SESSION[MESSAGE_TYPE] = "";
		return true;
	} elseif (isset($_SESSION[MESSAGE_TEXT_ERROR_IPL]) && $_SESSION[MESSAGE_TEXT_ERROR_IPL] <> "") {
		//var_dump($_SESSION[MESSAGE_TEXT]); exit();


		echo '
<div class="alert mx-auto"
tyle=" display: block;
    position: fixed;
    z-index: 9999;
    background-color: red;
    left: 25%;
    top: 50%;
    right: 25%;
    color: red;"
data-notify="container">

<span data-notify="message" style="color:red;">' . $_SESSION[MESSAGE_TEXT_ERROR_IPL] . '</span>
</div>
';
		/*echo '<div class="col-lg-6 mb-4">
                  <div class="card bg-success text-white shadow">
                    <div class="card-body">
                      '.$_SESSION[MESSAGE_TEXT_ERROR].'
                      <div class="text-white-50 small">#1cc88a</div>
                    </div>
                  </div>
                </div>'; */
		/*	echo '<div class="alert">
  <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
  <i>'.$_SESSION[MESSAGE_TEXT].'</i>
</div>'; */


		$_SESSION[MESSAGE_TEXT_ERROR_IPL] = "";
		//$_SESSION[MESSAGE_TYPE] = "";
		return true;
	}
	return false;
}





function clean($string)
{
	$string = str_replace(' ', '-', $string);

	return preg_replace('/[^A-Za-z0-9\-]/', '', $string);
}




function get_user_id($id)
{

	global $objDB;
	$val = '';

	$Query  = "SELECT * FROM " . TBL_USERS . " WHERE mobilenumber=" . $id;
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$val = $rsTotal[0]['user_id'];

	return $val;
}
function total_depo_pen()
{

	global $objDB;
	$val = '';

	$Query  = "SELECT count(mlb_id) as d_pen FROM " . TBL_MAS_LOAD_BALANCE . " WHERE txn_status='Pending'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$val = $rsTotal[0]['d_pen'];

	return $val;
}
function last_week_depo()
{

	global $objDB;
	$val = '';

	$Query  = "SELECT SUM(txn_amount) as week_depo FROM " . TBL_MAS_LOAD_BALANCE . " WHERE bank_name<>'Joining Bonus' AND txn_status='TXN_SUCCESS' AND WEEK(update_times,1)=WEEK(CURDATE(),1) AND YEAR(update_times)=YEAR(CURDATE())";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$val = $rsTotal[0]['week_depo'];

	return $val;
}
function last_week_with()
{

	global $objDB;
	$val = '';
	$now = date('d-m-Y h:i A');
	$Query  = "SELECT SUM(sell_amount) as week_sell FROM " . TBL_MAS_SELL_DATA . " WHERE sell_status='Done' AND WEEK(DATE_FORMAT(process_time, '%Y-%m-%d'),1)=WEEK(CURDATE(),1) AND YEAR(DATE_FORMAT(process_time, '%Y-%m-%d'))=YEAR(CURDATE())";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$val = $rsTotal[0]['week_sell'];

	return $val;
}
function curr_date_depo()
{

	global $objDB;
	$val = '';
	$udate = date('Y-m-d');
	$Query  = "SELECT SUM(txn_amount) as month_depo FROM " . TBL_MAS_LOAD_BALANCE . " WHERE bank_name<>'Joining Bonus' AND bank_name<>'Referral' AND txn_status='TXN_SUCCESS' AND DATE(update_times)=CURDATE()
       and YEAR(update_times)=YEAR(CURDATE())";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$val = $rsTotal[0]['month_depo'];

	return $val;
}
function curr_date_with()
{

	global $objDB;
	$val = '';
	$now = date('d-m-Y h:i A');
	$Query  = "SELECT SUM(sell_amount) as week_sell FROM " . TBL_MAS_SELL_DATA . " WHERE sell_status='Done' AND DATE(process_time)=DATE(CURDATE()) and YEAR(process_time)=YEAR(CURDATE())";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$val = $rsTotal[0]['week_sell'];

	return $val;
}
function curr_month_depo()
{

	global $objDB;
	$val = '';
	$now = date('Y-m-d H:i A');
	$Query  = "SELECT SUM(txn_amount) as month_depo FROM " . TBL_MAS_LOAD_BALANCE . " WHERE bank_name<>'Joining Bonus' AND bank_name<>'Referral' AND txn_status='TXN_SUCCESS' AND MONTH(update_times)=MONTH(CURDATE()) and YEAR(update_times)=YEAR(CURDATE())";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$val = $rsTotal[0]['month_depo'];

	return $val;
}
function curr_month_with()
{

	global $objDB;
	$val = '';
	$now = date('Y-m-d H:i A');
	$Query  = "SELECT SUM(sell_amount) as week_sell FROM " . TBL_MAS_SELL_DATA . " WHERE sell_status='Done' AND MONTH(process_time)=MONTH(CURDATE()) and YEAR(process_time)=YEAR(CURDATE())";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$val = $rsTotal[0]['week_sell'];

	return $val;
}
function get_user_count($id)
{

	global $objDB;
	$val = '';

	$Query  = "SELECT COUNT(mobilenumber) AS countuser FROM " . TBL_USERS . " WHERE user_type='user' AND user_status='Active'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$val = $rsTotal[0]['countuser'];


	return $val;
}

function get_available_bal($id)
{

	global $objDB;
	$val = '';

	$Query  = "SELECT SUM(txn_amount) AS loadbalance FROM " . TBL_MAS_LOAD_BALANCE . " WHERE txn_status='TXN_SUCCESS' and user_id=" . $id . "";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$loadbalance = $rsTotal[0]['loadbalance'];
	$Query1  = "SELECT SUM(sell_amount) AS widh_balance FROM " . TBL_MAS_SELL_DATA . " WHERE  user_id=" . $id . "";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	$widh_balance = $rsTotal1[0]['widh_balance'];
	$Query3  = "SELECT SUM(opp_bet_amount) AS oppbetamount,SUM(self_bet_amount) as selfbetamount, SUM(after_com_amount) AS commission FROM " . TBL_GAME_TRANS . " WHERE game_status='Complete' AND winner_id=" . $id . "  ";
	$objDB->setQuery($Query3);
	$rsTotal3 = $objDB->select();

	$winamount = $rsTotal3[0]['oppbetamount'] + $rsTotal3[0]['selfbetamount'] - $rsTotal3[0]['commission'];

	$Query2  = "SELECT SUM(self_bet_amount) AS betamount FROM " . TBL_GAME_TRANS . " WHERE (game_status='Running' OR game_status!='Cancel')  AND (game_create_by=" . $id . " OR opp_id=" . $id . ")   ";
	$objDB->setQuery($Query2);
	$rsTotal2 = $objDB->select();
	$bet_balance = $rsTotal2[0]['betamount'];
	$val = $loadbalance - $widh_balance - $bet_balance;
	$val = $val + $winamount;



	return $val;
}


function get_total_deposit()
{

	global $objDB;
	$val = '';

	$Query  = "SELECT SUM(txn_amount) AS loadbalance FROM " . TBL_MAS_LOAD_BALANCE . " WHERE txn_status='TXN_SUCCESS'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$loadbalance = $rsTotal[0]['loadbalance'];

	$val = $loadbalance;




	return $val;
}
function daily_ludo_ref($id)
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query  = "SELECT SUM(txn_amount) AS daily_ref FROM " . TBL_MAS_LOAD_BALANCE . " WHERE bank_name='Referral' AND DATE(update_time)=CURDATE() AND user_id='" . $id . "' ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$ref_bal_daily = $rsTotal[0]['daily_ref'];

	$val = $ref_bal_daily;
	return $val;
}
function mtd_ludo_ref($id)
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query  = "SELECT SUM(txn_amount) AS mtd_ref FROM " . TBL_MAS_LOAD_BALANCE . " WHERE bank_name='Referral' AND MONTH(update_time)=MONTH(CURDATE()) AND YEAR(update_time)=YEAR(CURDATE()) AND user_id='" . $id . "' ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$ref_bal_daily = $rsTotal[0]['mtd_ref'];

	$val = $ref_bal_daily;
	return $val;
}
function monthly_avm_ref($id)
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query  = "SELECT  SUM(referral_amount) AS monthly_ref FROM " . TBL_RKD_LEDGER . " WHERE referred_by='" . $id . "' AND MONTH(insert_time)=MONTH(CURDATE()) AND YEAR(insert_time)=YEAR(CURDATE()) ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$ref_bal_monthly = $rsTotal[0]['monthly_ref'];

	$val = $ref_bal_monthly;
	return $val;
}
function rkd_game_name($code)
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query  = "SELECT rkd_game_name,game_mode FROM " . TBL_RKD_GAME_LOG . " WHERE game_code = '" . $code . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$game_name = $rsTotal[0]['rkd_game_name'] . " " . $rsTotal[0]['game_mode'];

	$val = $game_name;
	return $val;
}
function rkd_total_widh()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query  = "SELECT  SUM(win_amount) AS monthly_ref FROM " . TBL_RKD_LEDGER . " ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$ref_bal_monthly = $rsTotal[0]['monthly_ref'];

	$val = $ref_bal_monthly;
	return $val;
}
function rkd_total_bid()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query  = "SELECT  SUM(b_amount) AS monthly_ref FROM " . TBL_RKD_LEDGER . " ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$ref_bal_monthly = $rsTotal[0]['monthly_ref'];

	$val = $ref_bal_monthly;
	return $val;
}
function monthly_avm_bid()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query  = "SELECT  SUM(b_amount) AS monthly_bid FROM " . TBL_RKD_LEDGER . "  WHERE MONTH(insert_time)=MONTH(CURDATE()) AND YEAR(insert_time)=YEAR(CURDATE())";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$ref_bal_monthly = $rsTotal[0]['monthly_bid'];

	$val = $ref_bal_monthly;
	return $val;
}
function monthly_avm_widh()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query  = "SELECT  SUM(win_amount) AS monthly_bid FROM " . TBL_RKD_LEDGER . "  WHERE MONTH(insert_time)=MONTH(CURDATE()) AND YEAR(insert_time)=YEAR(CURDATE())";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$ref_bal_monthly = $rsTotal[0]['monthly_bid'];

	$val = $ref_bal_monthly;
	return $val;
}
function last_avm_week_bid()
{

	global $objDB;
	$val = '';
	$now = date('d-m-Y h:i A');
	$Query  = "SELECT SUM(b_amount) as week_bid FROM " . TBL_RKD_LEDGER . " WHERE WEEKOFYEAR(DATE_FORMAT(insert_time, '%Y-%m-%d'))=WEEKOFYEAR(CURDATE())";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$val = $rsTotal[0]['week_bid'];

	return $val;
}
function last_avm_week_widh()
{

	global $objDB;
	$val = '';
	$now = date('d-m-Y h:i A');
	$Query  = "SELECT SUM(win_amount) as week_bid FROM " . TBL_RKD_LEDGER . " WHERE WEEKOFYEAR(DATE_FORMAT(insert_time, '%Y-%m-%d'))=WEEKOFYEAR(CURDATE())";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$val = $rsTotal[0]['week_bid'];

	return $val;
}
function today_avm_bid()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . "  WHERE DATE(insert_time)=CURDATE() ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$ref_bal_monthly = $rsTotal[0]['today_bid'];

	$val = $ref_bal_monthly;
	return $val;
}
function today_avm_widh()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query  = "SELECT  SUM(win_amount) AS today_widh FROM " . TBL_RKD_LEDGER . "  WHERE DATE(insert_time)=CURDATE() ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$ref_bal_monthly = $rsTotal[0]['today_widh'];

	$val = $ref_bal_monthly;
	return $val;
}

function total_avm_ref($id)
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query  = "SELECT  SUM(referral_amount) AS total_rkd_ref FROM " . TBL_RKD_LEDGER . " WHERE referred_by='" . $id . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$ref_bal_total = $rsTotal[0]['total_rkd_ref'];

	$val = $ref_bal_total;
	return $val;
}
function today_avm_bid_balaji_mor()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT  game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Shri Balaji' AND game_mode='Morning' and (game_status='active' OR game_status='Pending')";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	// 	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE DATE(insert_time)=CURDATE() AND game_code='".$rsTotal1[0]['game_code']."' ";
	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE game_code='" . $rsTotal1[0]['game_code'] . "' ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_widh_balaji_mor()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Shri Balaji' AND game_mode='Morning' and DATE(closegame_end_time)=CURDATE()";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	$Query  = "SELECT  SUM(win_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE  game_code='" . $rsTotal1[0]['game_code'] . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_bid_sridevi()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT  game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Sridevi' AND game_mode='' and (game_status='active' OR game_status='Pending')";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	// 	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE DATE(insert_time)=CURDATE() AND game_code='".$rsTotal1[0]['game_code']."' ";
	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE  game_code='" . $rsTotal1[0]['game_code'] . "' ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_widh_sridevi()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Sridevi' AND game_mode=''  and DATE(closegame_end_time)=CURDATE()";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	$Query  = "SELECT  SUM(win_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE  game_code='" . $rsTotal1[0]['game_code'] . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_bid_madhur_day()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT  game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Madhur' AND game_mode='Day' and (game_status='active' OR game_status='Pending')";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	// 	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE DATE(insert_time)=CURDATE() AND game_code='".$rsTotal1[0]['game_code']."' ";
	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE  game_code='" . $rsTotal1[0]['game_code'] . "' ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_widh_madhur_day()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Madhur' AND game_mode='Day' and DATE(closegame_end_time)=CURDATE()";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	$Query  = "SELECT  SUM(win_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE  game_code='" . $rsTotal1[0]['game_code'] . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_bid_time_bazar()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT  game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Time Bazar' AND game_mode='' and (game_status='active' OR game_status='Pending')";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	// 	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE DATE(insert_time)=CURDATE() AND game_code='".$rsTotal1[0]['game_code']."' ";
	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE game_code='" . $rsTotal1[0]['game_code'] . "' ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_widh_time_bazar()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Time Bazar' AND game_mode='' and DATE(closegame_end_time)=CURDATE()";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	$Query  = "SELECT  SUM(win_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE  game_code='" . $rsTotal1[0]['game_code'] . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_bid_milan_day()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT  game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Milan' AND game_mode='Day' and (game_status='active' OR game_status='Pending')";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	// 	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE DATE(insert_time)=CURDATE() AND game_code='".$rsTotal1[0]['game_code']."' ";
	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE game_code='" . $rsTotal1[0]['game_code'] . "' ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_widh_milan_day()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Milan' AND game_mode='Day' and DATE(closegame_end_time)=CURDATE()";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	$Query  = "SELECT  SUM(win_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE  game_code='" . $rsTotal1[0]['game_code'] . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_bid_balaji_eve()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT  game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Shri Balaji' AND game_mode='Evening' and (game_status='active' OR game_status='Pending')";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	// 	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE DATE(insert_time)=CURDATE() AND game_code='".$rsTotal1[0]['game_code']."' ";
	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE  game_code='" . $rsTotal1[0]['game_code'] . "' ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_widh_balaji_eve()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Shri Balaji' AND game_mode='Evening' and DATE(closegame_end_time)=CURDATE()";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	$Query  = "SELECT  SUM(win_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE  game_code='" . $rsTotal1[0]['game_code'] . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_bid_balaji_night()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT  game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Shri Balaji' AND game_mode='Night' and (game_status='active' OR game_status='Pending')";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	// 	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE DATE(insert_time)=CURDATE() AND game_code='".$rsTotal1[0]['game_code']."' ";
	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE  game_code='" . $rsTotal1[0]['game_code'] . "' ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_widh_balaji_night()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Shri Balaji' AND game_mode='Night' and DATE(closegame_end_time)=CURDATE()";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	$Query  = "SELECT  SUM(win_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE  game_code='" . $rsTotal1[0]['game_code'] . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_bid_kalyan_night()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT  game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Kalyan' AND game_mode='Night' and (game_status='active' OR game_status='Pending')";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	// 	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE DATE(insert_time)=CURDATE() AND game_code='".$rsTotal1[0]['game_code']."' ";
	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE  game_code='" . $rsTotal1[0]['game_code'] . "' ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_widh_kalyan_night()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Kalyan' AND game_mode='Night' and DATE(closegame_end_time)=CURDATE()";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	$Query  = "SELECT  SUM(win_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE  game_code='" . $rsTotal1[0]['game_code'] . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_bid_rajdhani_day()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT  game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Rajdhani' AND game_mode='Day' and (game_status='active' OR game_status='Pending')";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	// 	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE DATE(insert_time)=CURDATE() AND game_code='".$rsTotal1[0]['game_code']."' ";
	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE  game_code='" . $rsTotal1[0]['game_code'] . "' ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_widh_rajdhani_day()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Rajdhani' AND game_mode='Day' and DATE(closegame_end_time)=CURDATE()";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	$Query  = "SELECT  SUM(win_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE  game_code='" . $rsTotal1[0]['game_code'] . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_bid_kalyan()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT  game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Kalyan' AND game_mode='' and (game_status='active' OR game_status='Pending')";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	// 	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE DATE(insert_time)=CURDATE() AND game_code='".$rsTotal1[0]['game_code']."' ";
	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE  game_code='" . $rsTotal1[0]['game_code'] . "' ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_widh_kalyan()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Kalyan' AND game_mode='' and DATE(closegame_end_time)=CURDATE()";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	$Query  = "SELECT  SUM(win_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE game_code='" . $rsTotal1[0]['game_code'] . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_bid_sridevi_night()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT  game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Sridevi' AND game_mode='Night' and (game_status='active' OR game_status='Pending')";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	// 	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE DATE(insert_time)=CURDATE() AND game_code='".$rsTotal1[0]['game_code']."' ";
	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE  game_code='" . $rsTotal1[0]['game_code'] . "' ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_widh_sridevi_night()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Sridevi' AND game_mode='Night' and DATE(closegame_end_time)=CURDATE()";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	$Query  = "SELECT  SUM(win_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE game_code='" . $rsTotal1[0]['game_code'] . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_bid_madhur_night()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT  game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Madhur' AND game_mode='Night' and (game_status='active' OR game_status='Pending')";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	// 	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE DATE(insert_time)=CURDATE() AND game_code='".$rsTotal1[0]['game_code']."' ";
	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE game_code='" . $rsTotal1[0]['game_code'] . "' ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_widh_madhur_night()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Madhur' AND game_mode='Night' and DATE(closegame_end_time)=CURDATE()";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	$Query  = "SELECT  SUM(win_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE game_code='" . $rsTotal1[0]['game_code'] . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_bid_milan_night()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT  game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Milan' AND game_mode='Night' and (game_status='active' OR game_status='Pending')";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	// 	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE DATE(insert_time)=CURDATE() AND game_code='".$rsTotal1[0]['game_code']."' ";
	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE  game_code='" . $rsTotal1[0]['game_code'] . "' ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_widh_milan_night()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Milan' AND game_mode='Night' and DATE(closegame_end_time)=CURDATE()";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	$Query  = "SELECT  SUM(win_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE game_code='" . $rsTotal1[0]['game_code'] . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_bid_rajdhani_night()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT  game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Rajdhani' AND game_mode='Night' and (game_status='active' OR game_status='Pending')";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	// 	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE DATE(insert_time)=CURDATE() AND game_code='".$rsTotal1[0]['game_code']."' ";
	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE  game_code='" . $rsTotal1[0]['game_code'] . "' ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_widh_rajdhani_night()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Rajdhani' AND game_mode='Night' and DATE(closegame_end_time)=CURDATE()";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	$Query  = "SELECT  SUM(win_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE game_code='" . $rsTotal1[0]['game_code'] . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_bid_main_bazar()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT  game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Main Bazar' AND game_mode='' and (game_status='active' OR game_status='Pending')";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	// 	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE DATE(insert_time)=CURDATE() AND game_code='".$rsTotal1[0]['game_code']."' ";
	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE  game_code='" . $rsTotal1[0]['game_code'] . "' ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_widh_main_bazar()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Main Bazar' AND game_mode='' and DATE(closegame_end_time)=CURDATE()";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	$Query  = "SELECT  SUM(win_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE game_code='" . $rsTotal1[0]['game_code'] . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_bid_madhur_morning()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT  game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Madhur' AND game_mode='Morning' and (game_status='active' OR game_status='Pending')";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	// 	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE DATE(insert_time)=CURDATE() AND game_code='".$rsTotal1[0]['game_code']."' ";
	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE  game_code='" . $rsTotal1[0]['game_code'] . "' ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_widh_madhur_morning()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Madhur' AND game_mode='Morning' and DATE(closegame_end_time)=CURDATE()";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	$Query  = "SELECT  SUM(win_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE game_code='" . $rsTotal1[0]['game_code'] . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_bid_delhi_avm()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT  game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Delhi' AND game_mode='AVM' and (game_status='active' OR game_status='Pending')";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	// 	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE DATE(insert_time)=CURDATE() AND game_code='".$rsTotal1[0]['game_code']."' ";
	$Query  = "SELECT  SUM(b_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE  game_code='" . $rsTotal1[0]['game_code'] . "' ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function today_avm_widh_delhi_avm()
{

	global $objDB;
	$val = '';
	// $today_date = date();
	$Query1  = "SELECT game_code FROM " . TBL_RKD_GAME_LOG . " WHERE rkd_game_name='Delhi' AND game_mode='AVM' and DATE(closegame_end_time)=CURDATE()";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	$Query  = "SELECT  SUM(win_amount) AS today_bid FROM " . TBL_RKD_LEDGER . " WHERE game_code='" . $rsTotal1[0]['game_code'] . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$today_bid = $rsTotal[0]['today_bid'];

	$val = $today_bid;
	return $val;
}
function get_admin_id()
{

	global $objDB;
	$val = '';

	$Query  = "SELECT user_id FROM " . TBL_USERS . " WHERE user_type='admin'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$admin_id = $rsTotal[0]['user_id'];

	$val = $admin_id;
	return $val;
}
function get_admin_number()
{

	global $objDB;
	$val = '';

	$Query  = "SELECT mobilenumber FROM " . TBL_USERS . " WHERE user_type='admin'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$admin_id = $rsTotal[0]['mobilenumber'];

	$val = $admin_id;
	return $val;
}
function user_bet_count($id, $pet_id)
{

	global $objDB;
	$val = '';

	$Query  = "SELECT COUNT( Distinct user_id ) as usr_count FROM " . TBL_GAME_TRANS_TITLEE . " WHERE bet_pet='" . $pet_id . "' AND game_code='" . $id . "' ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$count = $rsTotal[0]['usr_count'];

	$val = $count;
	return $val;
}
function user_total_bet_count($id)
{

	global $objDB;
	$val = '';

	$Query  = "SELECT COUNT( Distinct user_id ) as usr_count FROM " . TBL_GAME_TRANS_TITLEE . " WHERE game_code='" . $id . "' ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$count = $rsTotal[0]['usr_count'];

	$val = $count;
	return $val;
}
function get_total_bet_amount($id)
{

	global $objDB;
	$val = '';

	$Query  = "SELECT SUM(bet_amount) as b_amount FROM " . TBL_GAME_TRANS_TITLEE . " WHERE game_code='" . $id . "' ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$count = $rsTotal[0]['b_amount'];

	$val = $count;
	return $val;
}

function get_total_withdrawl()
{

	global $objDB;
	$val = '';

	$Query  = "SELECT SUM(sell_amount) AS withdrawlbalance FROM " . TBL_MAS_SELL_DATA . " WHERE sell_status='Done'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$wdhbalance = $rsTotal[0]['withdrawlbalance'];
	if ($wdhbalance == 0) {
		$val = 0;
	} else {
		$val = $wdhbalance;
	}


	return $val;
}
function get_total_commission()
{

	global $objDB;
	$val = '';

	$Query  = "SELECT SUM(after_com_amount) AS commission_amount FROM " . TBL_GAME_TRANS . " ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$Query10  = "SELECT user_id FROM " . TBL_USERS . " WHERE user_type= 'admin' ";
	$objDB->setQuery($Query10);
	$rsTotal10 = $objDB->select();
	$Query1  = "SELECT SUM(com_amount) AS tit_commission_amount FROM " . TBL_TRANSACTION . " WHERE user_id= '" . $rsTotal10[0]['user_id'] . "' ";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	$combalance = $rsTotal[0]['commission_amount'] + $rsTotal1[0]['tit_commission_amount'];
	if ($combalance == 0) {
		$val = 0;
	} else {
		$val = $combalance;
	}


	return $val;
}

function get_bet_amount($id)
{

	global $objDB;
	$val = '';

	$Query  = "SELECT self_bet_amount AS betamount FROM " . TBL_GAME_TRANS . " WHERE game_id='" . $id . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$bet_amount = $rsTotal[0]['betamount'];

	$val = $bet_amount;




	return $val;
}

function pending_withdrawl_req()
{

	global $objDB;
	$val = '';

	$Query  = "SELECT COUNT(sell_req_id) AS pending_id FROM " . TBL_MAS_SELL_DATA . " WHERE sell_status='In Process'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$pending_id = $rsTotal[0]['pending_id'];
	if ($pending_id == 0) {
		$val = 0;
	} else {
		$val = $pending_id;
	}


	return $val;
}



function getfName($id)
{
	global $objDB;
	$val = 'Unknown';
	if (is_numeric($id)) {
		$Query  = "SELECT * FROM " . TBL_USERS . " WHERE user_id=" . $id;
		$objDB->setQuery($Query);
		$rsTotal = $objDB->select();
		if (count($rsTotal) == 1) {
			$val = strtolower($rsTotal[0]['fname']);
		}
	}
	return $val;
}
function getUserName($id)
{
	global $objDB;
	$val = 'Unknown';
	if (is_numeric($id)) {
		$Query  = "SELECT * FROM " . TBL_USERS . " WHERE user_id=" . $id;
		$objDB->setQuery($Query);
		$rsTotal = $objDB->select();
		if (count($rsTotal) == 1) {
			$val = $rsTotal[0]['username'];
		}
	}
	return $val;
}
function get_opp_UserName($id)
{
	global $objDB;
	$val = 'Unknown';
	if (is_numeric($id)) {
		$Query  = "SELECT * FROM " . TBL_USERS . " WHERE user_id=" . $id;
		$objDB->setQuery($Query);
		$rsTotal = $objDB->select();
		if (count($rsTotal) == 1) {
			$val = strtolower($rsTotal[0]['fname']);
		}
	}
	return $val;
}
function getUserName_duser($id)
{
	global $objDB;
	$val = 'Unknown';
	if (is_numeric($id)) {
		$Query  = "SELECT * FROM " . TBL_DEMO_USR . " WHERE d_id=" . $id;
		$objDB->setQuery($Query);
		$rsTotal = $objDB->select();
		if (count($rsTotal) == 1) {
			$val = strtolower($rsTotal[0]['fname']);
		}
	}
	return $val;
}



function getRefEarning($id)
{
	global $objDB;
	$val = 'Unknown';
	if (is_numeric($id)) {
		$Query  = "SELECT SUM(amount) as ref_ear FROM " . TBL_USER_LOG . " WHERE txn_type = 'Referral' and  user_id=" . $id;
		$objDB->setQuery($Query);
		$rsTotal = $objDB->select();

		$val = $rsTotal[0]['ref_ear'];
	}
	return $val;
}

function getRefEarning_titlee($id)
{
	global $objDB;
	$val = 'Unknown';
	if (is_numeric($id)) {
		$Query  = "SELECT SUM(com_amount) as ref_ear FROM " . TBL_TRANSACTION . " WHERE txn_type = 'Referral' and  user_id=" . $id;
		$objDB->setQuery($Query);
		$rsTotal = $objDB->select();

		$val = $rsTotal[0]['ref_ear'];
	}
	return $val;
}

function getRefEarning_titlee_mtd($id)
{
	global $objDB;
	$val = 'Unknown';
	if (is_numeric($id)) {
		$Query  = "SELECT SUM(com_amount) as ref_ear FROM " . TBL_TRANSACTION . " WHERE MONTH(insert_date)=MONTH(CURDATE()) AND YEAR(insert_date)=YEAR(CURDATE()) AND txn_type = 'Referral' and  user_id=" . $id;
		$objDB->setQuery($Query);
		$rsTotal = $objDB->select();

		$val = $rsTotal[0]['ref_ear'];
	}
	return $val;
}
function getRefEarning_cric_mtd($id)
{
	global $objDB;
	$val = 'Unknown';
	if (is_numeric($id)) {
		$Query  = "SELECT SUM(referral_amt) as ref_ear FROM " . TBL_IPL_BETTING . " WHERE MONTH(insert_time)=MONTH(CURDATE()) AND YEAR(insert_time)=YEAR(CURDATE()) AND referred_by=" . $id;
		$objDB->setQuery($Query);
		$rsTotal = $objDB->select();
		if ($rsTotal[0]['ref_ear'] === NULL) {
			$val = 0;
		} else {
			$val = $rsTotal[0]['ref_ear'];
		}
	}
	return $val;
}

function getTotalRef($id)
{
	global $objDB;
	$val = 'Unknown';
	if (is_numeric($id)) {
		$number = getUserNumber($id);
		$Query  = "SELECT count(user_id) as total_ref FROM " . TBL_USERS . " WHERE rfcode=" . $number;
		$objDB->setQuery($Query);
		$rsTotal = $objDB->select();

		$val = $rsTotal[0]['total_ref'];
	}
	return $val;
}

function getUserNumber($id)
{
	global $objDB;
	$val = 'Unknown';
	if (is_numeric($id)) {
		$Query  = "SELECT * FROM " . TBL_USERS . " WHERE user_id=" . $id;
		$objDB->setQuery($Query);
		$rsTotal = $objDB->select();
		if (count($rsTotal) == 1) {
			$val = strtolower($rsTotal[0]['mobilenumber']);
		}
	}
	return $val;
}
// Titlee Function Start 


function get_animal_name($id)
{

	global $objDB;
	$val = '';

	$Query  = "SELECT * FROM " . TBL_ANIMALS . " WHERE anim_id=" . $id;
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$val = $rsTotal[0]['pet_name'];

	return $val;
}

function get_emergency_no()
{

	global $objDB;
	$val = '';

	$Query  = "SELECT * FROM " . TBL_PAYTM_MASTER . "";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$val = $rsTotal[0]['emergency_con'];

	return $val;
}




function get_last_news()
{

	global $objDB;
	$val = '';

	$Query  = "SELECT * FROM " . TBL_RKD_NEWS . " ORDER BY news_id LIMIT 1";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$val = $rsTotal[0]['news_message'];

	return $val;
}

function get_rkd_gname($id)
{

	global $objDB;
	$val = '';

	$Query  = "SELECT rkd_game_name,game_mode FROM " . TBL_RKD_GAME_LOG . " WHERE game_code='" . $id . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$val = $rsTotal[0]['rkd_game_name'] . " " . $rsTotal[0]['game_mode'];


	return $val;
}

function get_total_bet($id)
{

	global $objDB;
	$val = '';

	$Query  = "SELECT COUNT(game_id) AS countbet FROM " . TBL_GAME_TRANS_TITLEE . " WHERE game_code='" . $id . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	// $val = $rsTotal[0]['countbet'];

	if ($rsTotal != '0') {
		$val = $rsTotal[0]['countbet'];
	} else {
		$val = '0';
	}

	return $val;
}

function get_total_betamount($id)
{

	global $objDB;
	$val = '';

	$Query  = "SELECT sum(bet_amount) AS betamount FROM " . TBL_GAME_TRANS_TITLEE . " WHERE game_code='" . $id . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	// $val = $rsTotal[0]['countbet'];

	if ($rsTotal != '') {
		$val = $rsTotal[0]['betamount'];
	} else {
		$val = "0";
	}

	return $val;
}

function get_rfcode($id)
{

	global $objDB;
	$val = '';

	$Query  = "SELECT * FROM " . TBL_USERS . " WHERE user_id='" . $id . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$val = $rsTotal[0]['rfcode'];


	return $val;
}
function get_rfid($id)
{

	global $objDB;
	$val = '';

	$Query  = "SELECT * FROM " . TBL_USERS . " WHERE user_id='" . $id . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$Query1  = "SELECT * FROM " . TBL_USERS . " WHERE mobilenumber='" . $rsTotal[0]['rfcode'] . "'";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	if ($rsTotal1[0]['user_id'] == '') {
		$Query2  = "SELECT * FROM " . TBL_USERS . " WHERE user_type='admin'";
		$objDB->setQuery($Query2);
		$rsTotal2 = $objDB->select();
		$val = $rsTotal2[0]['user_id'];
	} else {
		$val = $rsTotal1[0]['user_id'];
	}
	return $val;
}

function get_ref_percentage()
{

	global $objDB;
	$val = '';

	$Query  = "SELECT * FROM " . TBL_PAYTM_MASTER . " WHERE status='Active'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$val = $rsTotal[0]['referral_percentage'];


	return $val;
}

function get_act_game()
{

	global $objDB;
	$val = '';

	$Query  = "SELECT * FROM " . TBL_GAME_TAB . " WHERE game_status='Active'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$val = $rsTotal[0]['insert_date'];


	return $val;
}
function get_act_game_code()
{

	global $objDB;
	$val = '';

	$Query  = "SELECT * FROM " . TBL_GAME_TAB . " WHERE game_status='Active'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$val = $rsTotal[0]['game_code'];


	return $val;
}
function get_match_depo($id)
{

	global $objDB;
	$val = '';

	$Query  = "SELECT SUM(bid_amount) AS bid_amt, SUM(u2u_opponent_bid_amount) AS u2u_opp_bid_amt FROM " . TBL_IPL_BETTING . " WHERE match_id='" . $id . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$val = $rsTotal[0]['bid_amt'] + $rsTotal[0]['u2u_opp_bid_amt'];


	return $val;
}
function get_match_widh($id)
{

	global $objDB;
	$val = '';

	$Query  = "SELECT SUM(win_amount) AS win_amt,SUM(bid_amount) AS bid_amt, SUM(u2u_opp_win_amount) AS u2u_opp_win_amt, SUM(u2u_host_win_amount) AS u2u_host_win_amt,SUM(return_amount) AS return_amount FROM " . TBL_IPL_BETTING . " WHERE (game_status='Win' OR game_status='Return') AND match_id='" . $id . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$val = $rsTotal[0]['win_amt'] + $rsTotal[0]['u2u_opp_win_amt'] + $rsTotal[0]['u2u_host_win_amt'] + $rsTotal[0]['return_amount'] + $rsTotal[0]['bid_amt'];


	return $val;
}
function get_match_depo_total()
{

	global $objDB;
	$val = '';

	$Query  = "SELECT SUM(bid_amount) AS bid_amt, SUM(u2u_opponent_bid_amount) AS u2u_opp_bid_amt FROM " . TBL_IPL_BETTING . " ";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$val = $rsTotal[0]['bid_amt'] + $rsTotal[0]['u2u_opp_bid_amt'];


	return $val;
}
function get_match_widh_total()
{

	global $objDB;
	$val = '';

	$Query  = "SELECT SUM(win_amount) AS win_amt, SUM(u2u_opp_win_amount) AS u2u_opp_win_amt, SUM(u2u_host_win_amount) AS u2u_host_win_amt, SUM(return_amount) AS return_amount FROM " . TBL_IPL_BETTING . " WHERE (game_status='Win' OR game_status='Return')";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$val = $rsTotal[0]['win_amt'] + $rsTotal[0]['u2u_opp_win_amt'] + $rsTotal[0]['u2u_host_win_amt'] + $rsTotal[0]['return_amount'];


	return $val;
}
function get_available_bal_tit($id)
{

	global $objDB;
	$val = '';

	// Win Amount Calculation Start
	// $Query3  = "SELECT SUM(win_amount) AS win_amount, SUM(loss_amount) AS lossamount FROM " . TBL_TRANSACTION . " WHERE user_id='" . $id . "' AND toshow='Yes' ";
	// $objDB->setQuery($Query3);
	// $rsTotal3 = $objDB->select();
	$Query3  = "SELECT * FROM " . TBL_TITLEE_RECORD . " WHERE user_id='" . $id . "' ";
	$objDB->setQuery($Query3);
	$rsTotal3 = $objDB->select();
	$Query37  = "SELECT SUM(opp_bet_amount) AS oppbetamount,SUM(self_bet_amount) as selfbetamount, SUM(after_com_amount) AS commission FROM " . TBL_GAME_TRANS . " WHERE game_status='Complete' AND winner_id=" . $id . "  ";
	$objDB->setQuery($Query37);
	$rsTotal37 = $objDB->select();
	$winamount_ludo = $rsTotal37[0]['oppbetamount'] + $rsTotal37[0]['selfbetamount'] - $rsTotal37[0]['commission'];
	// Win Amount Calculation End

	// Withdraw Amount calculation Start
	$Query1  = "SELECT SUM(sell_amount) AS widh_balance FROM " . TBL_MAS_SELL_DATA . " WHERE  user_id=" . $id . "";
	$objDB->setQuery($Query1);
	$rsTotal1 = $objDB->select();
	$Query101  = "SELECT SUM(sell_amount) AS bonus_balance FROM " . TBL_MAS_SELL_DATA . " WHERE payment_source='Bonus Chips' AND  user_id=" . $id . "";
	$objDB->setQuery($Query101);
	$rsTotal101 = $objDB->select();

	// Deposit Amount Calculation Start
	$Query  = "SELECT SUM(txn_amount) AS total_deposit FROM " . TBL_MAS_LOAD_BALANCE . " WHERE txn_status='TXN_SUCCESS' AND user_id='" . $id . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$loadbalance = $rsTotal[0]['total_deposit'];
	// Deposit Amount Calculation End


	// Running Bet Calculation Start
	// 	$Query32  = "SELECT SUM(bet_amount) AS running_bet FROM " . TBL_GAME_TRANS_TITLEE . " WHERE (game_status = '' OR game_status='fpending' OR game_status='Hold') AND user_id='" . $id . "'  ";
	// 	$objDB->setQuery($Query32);
	// 	$rsTotal32 = $objDB->select();
	$Query2  = "SELECT SUM(self_bet_amount) AS betamount FROM " . TBL_GAME_TRANS . " WHERE (game_status='Running' OR game_status!='Cancel' OR game_status='Open')  AND (game_create_by=" . $id . " OR opp_id=" . $id . ")   ";
	$objDB->setQuery($Query2);
	$rsTotal2 = $objDB->select();
	// Running Bet Calculation End

	// $Query33  = "SELECT  SUM(com_amount) AS commison FROM " . TBL_TRANSACTION . " WHERE txn_type = 'Win' AND toshow='Yes' AND user_id='" . $id . "'  ";
	// $objDB->setQuery($Query33);
	// $rsTotal33 = $objDB->select();
	// $Query34  = "SELECT  SUM(com_amount) AS commison_earn FROM " . TBL_TRANSACTION . " WHERE txn_type = 'Referral' AND toshow='Yes' AND user_id='" . $id . "'  ";
	// $objDB->setQuery($Query34);
	// $rsTotal34 = $objDB->select();
	$rkd_w  = "SELECT  SUM(win_amount) AS win_amt_rkd FROM " . TBL_RKD_LEDGER . " WHERE bet_status = 'Win' AND (game_status='Finished' OR game_status='Pending') AND user_id='" . $id . "'  ";
	$objDB->setQuery($rkd_w);
	$rkd_win = $objDB->select();
	$rkd_pen  = "SELECT  SUM(b_amount) AS b_amt FROM " . TBL_RKD_LEDGER . " WHERE game_status='Pending' AND (temp_status='No' OR temp_status='Pending') AND user_id='" . $id . "'  ";
	$objDB->setQuery($rkd_pen);
	$rkd_pen_amt = $objDB->select();
	$rkd_game_amt  = "SELECT  SUM(b_amount) AS b_amt_g FROM " . TBL_RKD_LEDGER . " WHERE game_status='Finished' AND bet_status<>'Loss' AND user_id='" . $id . "'  ";
	$objDB->setQuery($rkd_game_amt);
	$rkd_g_amt = $objDB->select();
	$rkd_loss_amt  = "SELECT  SUM(b_amount) AS b_amt_l FROM " . TBL_RKD_LEDGER . " WHERE game_status='Finished' AND bet_status='Loss' AND user_id='" . $id . "'  ";
	$objDB->setQuery($rkd_loss_amt);
	$rkd_l_amt = $objDB->select();
	$rkd_ref_amt_s  = "SELECT  SUM(referral_amount) AS ref_amt_rkd FROM " . TBL_RKD_LEDGER . " WHERE referred_by='" . $id . "'  ";
	$objDB->setQuery($rkd_ref_amt_s);
	$rkd_ref_amt = $objDB->select();
	$rkd_ref_amt = $rkd_ref_amt[0]['ref_amt_rkd'];

	$rkd_total_bal = $rkd_win[0]['win_amt_rkd'] - ($rkd_g_amt[0]['b_amt_g'] + $rkd_pen_amt[0]['b_amt'] + $rkd_l_amt[0]['b_amt_l']);
	//IPL Game Calculation Start
	// $ipl_biding  = "SELECT  SUM(bid_amount) AS b_amt, SUM(win_amount) as w_amt FROM " . TBL_IPL_BETTING . " WHERE game_status='Active'  AND user_id='" . $id . "'  ";
	$ipl_biding  = "SELECT  SUM(bid_amount) AS b_amt, SUM(win_amount) as w_amt, SUM(return_amount) as return_amt  FROM " . TBL_IPL_BETTING . " WHERE user_id='" . $id . "' AND bid_type<>'User-User' ";
	$objDB->setQuery($ipl_biding);
	$ipl_biding = $objDB->select();

	$ipl_u2u_biding  = "SELECT  SUM(u2u_opponent_bid_amount) AS u2u_opp_b_amt, SUM(u2u_opp_win_amount) as u2u_opp_w_amt, SUM(u2u_opp_loss_amount) as u2u_opp_l_amt FROM " . TBL_IPL_BETTING . " WHERE bid_type='User-User' AND u2u_opponent='" . $id . "' ";
	$objDB->setQuery($ipl_u2u_biding);
	$ipl_u2u_biding = $objDB->select();
	$ipl_ref_earn  = "SELECT  SUM(referral_amt) AS referral_earn FROM " . TBL_IPL_BETTING . " WHERE referred_by='" . $id . "' ";
	$objDB->setQuery($ipl_ref_earn);
	$ipl_ref_earn = $objDB->select();
	$ipl_u2u_host  = "SELECT  SUM(bid_amount) AS u2u_host_bid_amount, SUM(u2u_host_win_amount) AS u2u_host_w_amt,SUM(u2u_host_loss_amount) AS u2u_host_l_amt FROM " . TBL_IPL_BETTING . " WHERE user_id='" . $id . "' AND bid_type='User-User' ";
	$objDB->setQuery($ipl_u2u_host);
	$ipl_u2u_host = $objDB->select();
	$ipl_win_bid_dedu  = "SELECT  SUM(bid_amount) AS dedu_win_bid_amount FROM " . TBL_IPL_BETTING . " WHERE user_id='" . $id . "' AND game_status='Win' AND bid_type<>'User-User' ";
	$objDB->setQuery($ipl_win_bid_dedu);
	$ipl_win_bid_dedu = $objDB->select();
	$dedu_win_bid_amount = $ipl_win_bid_dedu[0]['dedu_win_bid_amount'];
	$u2u_host_win_bid_amt =	"SELECT  SUM(bid_amount) AS dedu_u2u_win_bid_amount FROM " . TBL_IPL_BETTING . " WHERE u2u_created_by='" . $id . "' AND u2u_winner_id='" . $id . "' AND bid_type='User-User' ";
	$objDB->setQuery($u2u_host_win_bid_amt);
	$u2u_host_win_bid_amt = $objDB->select();
	$u2u_host_win_bid_amt = $u2u_host_win_bid_amt[0]['dedu_u2u_win_bid_amount'];
	$u2u_opp_win_bid_amt =	"SELECT  SUM(u2u_opponent_bid_amount) AS opp_u2u_win_bid_amount FROM " . TBL_IPL_BETTING . " WHERE u2u_opponent='" . $id . "' AND u2u_winner_id='" . $id . "' AND bid_type='User-User' ";
	$objDB->setQuery($u2u_opp_win_bid_amt);
	$u2u_opp_win_bid_amt = $objDB->select();
	$u2u_opp_win_bid_amt = $u2u_opp_win_bid_amt[0]['opp_u2u_win_bid_amount'];
	// $ch_pp_bid_chk = "SELECT  SUM(bid_amount) AS ch_pp_bid_chk FROM " . TBL_IPL_BETTING . " WHERE bid_type='Choose-Player' OR bid_type='Player-Player' AND game_status='Win' AND user_id='" . $id . "' ";
	// $objDB->setQuery($ch_pp_bid_chk);
	// $ch_pp_bid_chk = $objDB->select();

	$ipl_ref_earn = $ipl_ref_earn[0]['referral_earn'];
	$u2u_host_bid_amount = $ipl_u2u_host[0]['u2u_host_bid_amount'];
	$u2u_host_w_amount = $ipl_u2u_host[0]['u2u_host_w_amt'];
	$u2u_host_l_amount = $ipl_u2u_host[0]['u2u_host_l_amt'];
	// $ipl_bet_debt = $ipl_ref_debt[0]['u2u_b_amt'];
	$ipl_open_bid = $ipl_biding[0]['b_amt'];
	$ipl_win_amt = $ipl_biding[0]['w_amt'];
	$ipl_ref_amt = $ipl_biding[0]['ref_amt'];
	$ipl_return_amt = $ipl_biding[0]['return_amt'];
	$ipl_u2u_bid = $ipl_u2u_biding[0]['u2u_opp_b_amt'];
	$ipl_u2u_win_amt = $ipl_u2u_biding[0]['u2u_opp_w_amt'];
	$ipl_u2u_loss_amt = $ipl_u2u_biding[0]['u2u_opp_l_amt'];

	$commison_earn = $rsTotal3[0]['referral_earn'];
	// $commison_earn = $rsTotal34[0]['commison_earn'];
	// $titlee_running_bet = $rsTotal32[0]['running_bet'];
	$ludo_running_bet = $rsTotal2[0]['betamount'];
	// $total_running_bet = $titlee_running_bet + $ludo_running_bet;
	$total_amt =  $loadbalance;
	// Withdraw Balance Start

	$widh_balance = $rsTotal1[0]['widh_balance'];
	// Withdraw Balance End
	// $win_amt = $rsTotal3[0]['win_amount'] + $winamount_ludo + $ipl_win_amt + $ch_pp_bid_chk[0]['ch_pp_bid_chk'];
	$win_amt = $rsTotal3[0]['win_amount'] + $winamount_ludo + $ipl_win_amt;
	$com_amt = $rsTotal3[0]['referral_debt'];
	// $com_amt = $rsTotal33[0]['commison'];
	$loss_amt = $rsTotal3[0]['loss_amount'];
	//Old Working calculation
	// $calculation = ($win_amt + $total_amt + $commison_earn + $rkd_total_bal + $rkd_ref_amt + $ipl_win_amt  + $ipl_u2u_win_amt + $ipl_ref_earn) - ($loss_amt + $com_amt + $widh_balance + $total_running_bet + $ipl_open_bid +  $ipl_u2u_bid + $ipl_u2u_loss_amt + $ipl_ref_amt);
	// $calculation = ($win_amt + $total_amt + $rsTotal101[0]['bonus_balance'] + $rsTotal101[0]['bonus_balance'] + $commison_earn + $rkd_total_bal + $rkd_ref_amt + $ipl_ref_earn + $u2u_host_w_amount + $ipl_u2u_win_amt + $dedu_win_bid_amount + $u2u_host_win_bid_amt + $u2u_opp_win_bid_amt) - ($loss_amt + $com_amt  + $widh_balance + $total_running_bet + $ipl_open_bid + $u2u_host_l_amount + $u2u_host_bid_amount + $ipl_u2u_bid + $ipl_u2u_loss_amt);
	$calculation = ($win_amt + $total_amt + $ipl_return_amt + $rsTotal101[0]['bonus_balance'] + $rsTotal101[0]['bonus_balance'] + $commison_earn + $rkd_total_bal + $rkd_ref_amt + $ipl_ref_earn + $u2u_host_w_amount + $ipl_u2u_win_amt + $dedu_win_bid_amount + $u2u_host_win_bid_amt + $u2u_opp_win_bid_amt) - ($loss_amt + $com_amt  + $widh_balance + $ipl_open_bid + $u2u_host_bid_amount + $ipl_u2u_bid);
	$val =  $val + $calculation;
	// $val =   $calculation;



	return $val;
}

function get_bonus_amount($id)
{
	global $objDB;

	$loadbalance = get_bonus_cr_amount($id) - get_bonus_ded_amount($id);

	return $loadbalance;
}
function get_bonus_cr_amount($id)
{
	global $objDB;
	$Query  = "SELECT SUM(txn_amount) AS total_deposit FROM " . TBL_MAS_LOAD_BALANCE . " WHERE  bank_name='Bonus Chips' AND user_id='" . $id . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$loadbalance = $rsTotal[0]['total_deposit'];

	return $loadbalance;
}
function get_bonus_ded_amount($id)
{
	global $objDB;
	$Query  = "SELECT SUM(sell_amount) AS total_deposit FROM " . TBL_MAS_SELL_DATA . " WHERE  payment_source='Bonus Chips' AND user_id='" . $id . "'";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$loadbalance = $rsTotal[0]['total_deposit'];

	return $loadbalance;
}


// Titlee Function End

function sendSms($number, $com_message)
{
	global $objDB;
	$QU11  = "SELECT * FROM " . TBL_SMS_API . " ";
	$objDB->setQuery($QU11);
	$PR11 = $objDB->select();

	$online = file_get_contents("" . $PR11[0]['API_URL'] . "country=91&sender=TDINFT&route=4&mobiles=" . $number . "&authkey=" . $PR11[0]['API_KEY'] . "&message=" . urlencode($com_message) . "");
	//$online = file_get_contents("https://www.fast2sms.com/dev/bulk?authorization=ThvaVryMtoYkp8AKCl4fUFsXgHN5J9WZj7zSQIbixLwE0D316dZV4F9rbQKAULEhpqeCoHxTOPWSdNyj&sender_id=FSTSMS&message=".urlencode('This is a test message')."&language=english&route=p&numbers=".urlencode('8871448361')."");

	if ($online == true) {
		$_SESSION[MESSAGE_TEXT] = "Message Sent Successfully";
		header("location:" . SITE_URL . $_REQUEST['p'] . "");
		exit();
	} else {

		$_SESSION[MESSAGE_TEXT] = "Oops..  Message Sending Failed..";
		header("location:" . SITE_URL . $_REQUEST['p'] . "");
		exit();
	}
}

function sendOTP($number, $com_message)
{

	$online = file_get_contents("http://sms.abinfotech.net/api/sendhttp.php?authkey=141513AZgojy6V58a54498&mobiles=" . $number . "&message=" . urlencode($com_message) . "&sender=MMONEY");
}





function thumbnail($filethumb, $file, $Twidth, $Theight, $tag)
{
	list($width, $height, $type, $attr) = getimagesize($file);
	switch ($type) {
		case 1:
			$img = ImageCreateFromGIF($file);
			break;
		case 2:
			$img = ImageCreateFromJPEG($file);
			break;
		case 3:
			$img = ImageCreateFromPNG($file);
			break;
	}
	if ($tag == "width") //width contraint
	{
		$Theight = round(($height / $width) * $Twidth);
	} elseif ($tag == "height") //height constraint
	{
		$Twidth = round(($width / $height) * $Theight);
	} else {
		if ($width > $height)
			$Theight = round(($height / $width) * $Twidth);
		else
			$Twidth = round(($width / $height) * $Theight);
	}

	$thumb = imagecreatetruecolor($Twidth, $Theight);
	imagealphablending($thumb, false);
	imagesavealpha($thumb, true);
	if (imagecopyresampled($thumb, $img, 0, 0, 0, 0, $Twidth, $Theight, $width, $height)) {
		switch ($type) {
			case 1:
				ImageGIF($thumb, $filethumb);
				break;
			case 2:
				ImageJPEG($thumb, $filethumb);
				break;
			case 3:
				ImagePNG($thumb, $filethumb);
				break;
		}

		return true;
	}
}

function upload_image($file, $dir, $new_filename, $thumb_width)
{
	if ($_FILES[$file]['name'] != "") {
		$exp = explode('.', $_FILES[$file]['name']);
		$file_name = $new_filename . "." . $exp[1];
		$dir_thumb = $dir . "thumb/"; //Thumb directory
		$dir_normal = $dir . "normal/"; //Normal Directory where photo will stay
		list($width, $height, $type, $attr) = getimagesize($_FILES[$file]['tmp_name']);
		//var_dump($dir_normal); exit();
		if ($width > $thumb_width) //Checking the width of image
		{
			$Twidth = $thumb_width;
		} else {
			$Twidth = $width;
		}
		$Theight = $height;
		$tag = 'width';
		if (file_exists($dir_normal . $file_name)) {
			unlink($dir_normal . $file_name);
		}
		$result = move_uploaded_file($_FILES[$file]['tmp_name'], $dir_normal . $file_name); // Image will go to normal directory
		if ($result) {
			if (file_exists($dir_thumb . $file_name)) {
				unlink($dir_thumb . $file_name);
			}
			thumbnail($dir_thumb . $file_name, $dir_normal . $file_name, $Twidth, $Theight, $tag);
		}
		return true;
	} else {
		return false;
	}
}



function img_watermark($target, $newcopy, $ext)
{
	$wtrmrk_file = "../images/watermark.png";
	$watermark = imagecreatefrompng($wtrmrk_file);
	imagealphablending($watermark, false);
	imagesavealpha($watermark, true);

	if (strtolower($ext) == 'png') $img = imagecreatefrompng($target);
	elseif (strtolower($ext) == 'jpg') $img = imagecreatefromjpeg($target);

	$img_w = imagesx($img);
	$img_h = imagesy($img);
	$wtrmrk_w = imagesx($watermark);
	$wtrmrk_h = imagesy($watermark);
	$dst_x = ($img_w / 2) - ($wtrmrk_w / 2); // For centering the watermark on any image
	$dst_y = ($img_h / 2) - ($wtrmrk_h / 2); // For centering the watermark on any image
	imagecopy($img, $watermark, $dst_x, $dst_y, 0, 0, $wtrmrk_w, $wtrmrk_h);

	if (strtolower($ext) == 'png') {
		imagealphablending($img, false);
		imagesavealpha($img, true);
		header('Content-Type: image/png');
		imagepng($img, $newcopy);
	} elseif (strtolower($ext) == 'jpg') imagejpeg($img, $newcopy, 100);
	imagedestroy($img);
	imagedestroy($watermark);
}

// IPL Section Start

function get_team_name($id)
{

	global $objDB;
	$val = '';

	$Query  = "SELECT * FROM " . TBL_IPL_TEAM . " WHERE team_id=" . $id . "";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$val = $rsTotal[0]['team_name'];


	return $val;
}
function get_team_image($id)
{

	global $objDB;
	$val = '';

	$Query  = "SELECT * FROM " . TBL_IPL_TEAM . " WHERE team_id=" . $id . "";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$val = $rsTotal[0]['team_image'];


	return $val;
}
function get_team_short_name($id)
{

	global $objDB;
	$val = '';

	$Query  = "SELECT * FROM " . TBL_IPL_TEAM . " WHERE team_id=" . $id . "";
	$objDB->setQuery($Query);
	$rsTotal = $objDB->select();
	$val = $rsTotal[0]['short_name'];


	return $val;
}
