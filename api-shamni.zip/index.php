<?php
ob_start();
error_reporting(E_ALL & ~E_NOTICE);
include_once("lib/config.php");
include_once("lib/dbclass.php");
include_once("lib/lib.php");
header('Access-Control-Allow-Origin: *');
?>

<?php


(isset($_REQUEST['p']) && $_REQUEST['p'] != '') ? $p = $_REQUEST['p'] : $p = 'dashboard';

$objDB = new DB();
$QU  = "SELECT * FROM " . TBL_USERS . " WHERE mobilenumber='" . $_SESSION[USER_SESSION_VAR] . "'";
$objDB->setQuery($QU);
$rs = $objDB->select();
$objDB->close();

if (isset($_SESSION[USER_SESSION_VAR]) && $_SESSION[USER_SESSION_VAR] != '') {

  if (file_exists('includes/' . $p . '.php')) {

    $pa = $p . '.php';
  } else {
    $pa = '404.php';
  }

  include('includes/' . $pa);
} else if ($p == 'user_verification' && $_SESSION[AUTH_VER_VAR] != '') {
  include("includes/user_verification.php");
} else {
  //var_dump($p); exit();
  if ($p == 'forgotpassword') include("includes/forgotpassword.php");
  elseif ($p == 'register') include("includes/register.php");
  elseif ($p == 'otp_validation') include("includes/otp_validation.php");
  elseif ($p == 'forgotpw_ver') include("includes/forgotpw_ver.php");
  elseif ($p == 'resetpwd') include("includes/resetpwd.php");
  elseif ($p == 'terms') include("includes/terms.php");
  else include("includes/login.php");
}

?>
<script>
  $(document).ready(function(e) {
    $('#dvLoading').fadeOut(0);
    $('.alert p span').click(function(e) {
      $('.alert').fadeOut(500);
    });

    setTimeout(function() {
      $('.alert').fadeOut(1000);
    }, 2000);
  });
</script>
<!-- <?php
      if ($_SESSION[USER_VAR_ID] != '') {
      ?>
  <script>
    setInterval(function() {
      $.post("includes/check_user", {
          user_id: '<?php echo $_SESSION[USER_VAR_ID]; ?>',
        },
        function(response, status, data) {
          response = jQuery.parseJSON(response);
          if (response.msg == 'Blocked') {
            window.location.href = '<?php echo SITE_URL . "logout"; ?>';
          }
          return false;

        });

    }, 15000);
  </script>
<?php
      }
?> -->


<?php ShowMessage(); ?>